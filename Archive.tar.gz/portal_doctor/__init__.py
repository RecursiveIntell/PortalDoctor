"""Portal Doctor - Diagnose and fix Wayland screen-sharing issues."""

__version__ = "0.1.0"
