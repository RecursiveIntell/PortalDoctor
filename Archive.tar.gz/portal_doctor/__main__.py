"""Entry point for python -m portal_doctor."""

from .main import main

if __name__ == "__main__":
    main()
