"""ScreenCast test module for Portal Doctor."""

from .xdg_screencast import run_screencast_test

__all__ = ["run_screencast_test"]
