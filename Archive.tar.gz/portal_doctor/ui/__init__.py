"""UI module for Portal Doctor."""
